export { GitHubCopilotProvider } from "./github-copilot.js";
export { OpenRouterProvider } from "./openrouter.js";
import { GitHubCopilotProvider } from "./github-copilot.js";
import { OpenRouterProvider } from "./openrouter.js";
/** Ordered list of all registered providers. */
export const PROVIDERS = [
    GitHubCopilotProvider,
    OpenRouterProvider,
];
