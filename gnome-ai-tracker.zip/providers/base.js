/** Deserialise the provider-instances settings key into an array of ProviderInstance. */
export function loadInstances(settings) {
    const raw = settings.get_strv("provider-instances");
    const result = [];
    for (const entry of raw) {
        try {
            result.push(JSON.parse(entry));
        }
        catch {
            // skip corrupt entries
        }
    }
    return result;
}
/** Serialise a ProviderInstance array back into the settings key. */
export function saveInstances(settings, instances) {
    settings.set_strv("provider-instances", instances.map(i => JSON.stringify(i)));
}
